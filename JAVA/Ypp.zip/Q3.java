import java.*;
import java.util.Scanner;

class Test
{
     
     static int sum(int arr[])
     {
        int sum = 0; 
        for (int i=0;i<arr.length;i++)
        sum +=  arr[i];
        return sum;
     }
     

     public static void main(String[] args) 
    {   int i;
        Scanner input = new Scanner(System.in);
        System.out.print("Enter Size: ");
        int n = input.nextInt();
        int arr[] = new int[n];
        System.out.print("Enter Element: ");
        for(i=0;i<n;i++)
            arr[i]= input.nextInt();

        System.out.println("Sum of array =  "+sum(arr));
    }
 }