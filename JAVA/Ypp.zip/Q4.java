import java.*;
import java.util.Scanner;
import java.lang.Math;

public class Q4
{
	public static void main(String []args)
	{
		Scanner input = new Scanner(System.in);
		System.out.println("Enter valus of :-");
		System.out.println("P,R,N,T\n");
		int p = input.nextInt();
		double r = input.nextDouble();
		int n = input.nextInt();
		int t = input.nextInt();

		double res = comp(p,r,n,t);
		System.out.println("Compound Interest = "+res);
	}

	public static double comp(int p,double r,int n , int t)
	{
		double CI= p*(Math.pow((1+(r/n)),n*t)) ;
		return CI;
	}
} 