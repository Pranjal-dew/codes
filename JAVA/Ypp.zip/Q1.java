import java.*;
import java.util.Scanner;

class Sample
{
int a;
int b;
}

public class Q1
{
	public static void main(String args[])
	{
		Scanner in=new Scanner(System.in);
		System.out.print("Enter two numbers : ");
		Sample tmp=new Sample();
		tmp.a=in.nextInt();
		tmp.b=in.nextInt();
		int d=tmp.a*tmp.b;
		System.out.print(d);

	}
}