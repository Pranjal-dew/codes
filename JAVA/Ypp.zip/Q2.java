import java.*;
import java.util.Scanner;
import java.lang.Math;

public class Q2
{
	public static void main(String []args)
	{
		int k=4;
		Scanner input = new Scanner(System.in);
		
		while(k!=5)
		{
			System.out.println("=================================================================");
			System.out.println("Enter to calculate :-\n");
			System.out.println("1. Circle ");
			System.out.println("2. Square ");
			System.out.println("3. Rectangle ");
			System.out.println("4. Triangle ");
			System.out.println("5. Exit ");
			System.out.println("=================================================================");

			k = input.nextInt();
			switch(k)
			{
				case 1 :
				{
					
					Circle c1 = new Circle();
					
					break;
				}

				case 2 :
				{
					
					Square s1 = new Square();
					
					break;
				}

				case 3 :
				{
					
					Rectangle r1 = new Rectangle();
					
					break;
				}

				case 4 :
				{
					
					Triangle t1 = new Triangle();
					
					break;
				}

				case 5 :
				{
					k=5;
					break;
				}
			}
		}
	
	}
}

class Circle
{
	public static double Circle()
	{
		Scanner input = new Scanner(System.in);
		System.out.println("+++ CIRCLE +++");
		System.out.println("Enter Radius : ");
		double r = input.nextDouble();
		double area = (22/7)*r*r;
		double peri = 2*(22/7)*r;
		System.out.println("Area = "+area+"\nPerimeter = "+peri);
		return 0;
	}
}

class Square
{
	public static double Square()
	{Scanner input = new Scanner(System.in);
		System.out.println("+++ SQUARE +++");
					System.out.println("Enter Side : ");
		int a = input.nextInt();
		int area = a*a;
		int peri = 4*a;
		System.out.println("Area = "+area+"\nPerimeter = "+peri);
		return 0;
	}
} 

class Rectangle
{
	public static double Rectangle()
	{Scanner input = new Scanner(System.in);
		System.out.println("+++ Rectangle +++");
					System.out.println("Enter Sides : ");
						int a = input.nextInt();
					int b = input.nextInt();
		int area = a*b;
		int peri = 2*(a+b);

					System.out.println("Area = "+area+"\nPerimeter = "+peri);
					return 0;
	}
} 

class Triangle
{
	public static double Triangle()
	{Scanner input = new Scanner(System.in);
System.out.println("+++ Triangle +++");
					System.out.println("Enter Sides : ");
					int a = input.nextInt();
					int b = input.nextInt();
					int c = input.nextInt();
		double s = (a+b+c)/2;
		double area = Math.sqrt(s*(s-a)*(s-b)*(s-c)) ;
		double peri = a+b+c;

					System.out.println("Area = "+area+"\nPerimeter = "+peri);
					return 0;
	}
} 